-- phpMyAdmin SQL Dump
-- version 4.7.3
-- https://www.phpmyadmin.net/
--
-- Hôte : localhost:8889
-- Généré le :  lun. 19 mars 2018 à 22:02
-- Version du serveur :  5.6.35
-- Version de PHP :  7.1.8

SET FOREIGN_KEY_CHECKS=0;
SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `deal`
--
CREATE DATABASE IF NOT EXISTS `deal` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `deal`;

-- --------------------------------------------------------

--
-- Structure de la table `annonce`
--

DROP TABLE IF EXISTS `annonce`;
CREATE TABLE `annonce` (
  `id` int(10) UNSIGNED NOT NULL,
  `dispo` varchar(10) NOT NULL DEFAULT 'active',
  `titre` varchar(255) NOT NULL,
  `description_courte` varchar(255) NOT NULL,
  `description_longue` text NOT NULL,
  `prix` float NOT NULL,
  `photo` varchar(255) DEFAULT NULL,
  `ville` varchar(100) NOT NULL,
  `adresse` text NOT NULL,
  `code_postal` char(5) NOT NULL,
  `membre_id` int(10) UNSIGNED NOT NULL,
  `categorie_id` int(10) UNSIGNED NOT NULL,
  `region_id` int(10) UNSIGNED NOT NULL,
  `date_enregistrement` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `annonce`
--

INSERT INTO `annonce` (`id`, `dispo`, `titre`, `description_courte`, `description_longue`, `prix`, `photo`, `ville`, `adresse`, `code_postal`, `membre_id`, `categorie_id`, `region_id`, `date_enregistrement`) VALUES
(20, 'active', 'Pull élan', ' Quaeque, ut ea vina, quae vetustatem ferunt, esse debet suavissima; verumque illud est, quod dicitur, multos modios salis simul edendos esse, ut amicitiae munus expletum sit.\n Quaeque, ut ea vina, quae vetustatem ferunt, esse debet suavissima; verumque i', 'Pellentesque gravida dui id turpis tincidunt mollis. Nulla facilisi. Etiam quis enim lorem. Duis lobortis diam et dolor accumsan, nec fermentum urna scelerisque. Nulla aliquet tortor sed risus facilisis bibendum. Nulla facilisi. Suspendisse semper rutrum sapien vel cursus. Sed id urna dolor. Cras id ex ac lectus ornare bibendum ac nec enim. Fusce fringilla ornare erat, vitae congue sem consequat vitae. Nullam finibus iaculis sodales. Aliquam interdum interdum tellus sit amet rhoncus. Phasellus sed ante consequat, ornare ex ac, porttitor libero. Suspendisse laoreet metus libero, sit amet vulputate turpis pellentesque vel. ', 55, '26fac6db20dcad22a5b5ed80bb5bda91.jpg', 'Paris', '122-130 Rue de la Convention', '75015', 4, 10, 8, '2018-01-11 01:15:30'),
(22, 'active', 'Chapeau haut de forme', ' Quaeque, ut ea vina, quae vetustatem ferunt, esse debet suavissima; verumque illud est, quod dicitur, multos modios salis simul edendos esse, ut amicitiae munus expletum sit.\n', 'Pellentesque gravida dui id turpis tincidunt mollis. Nulla facilisi. Etiam quis enim lorem. Duis lobortis diam et dolor accumsan, nec fermentum urna scelerisque. Nulla aliquet tortor sed risus facilisis bibendum. Nulla facilisi. Suspendisse semper rutrum sapien vel cursus. Sed id urna dolor. Cras id ex ac lectus ornare bibendum ac nec enim. Fusce fringilla ornare erat, vitae congue sem consequat vitae. Nullam finibus iaculis sodales. Aliquam interdum interdum tellus sit amet rhoncus. Phasellus sed ante consequat, ornare ex ac, porttitor libero. Suspendisse laoreet metus libero, sit amet vulputate turpis pellentesque vel. ', 234, 'd0bdd79bbb79dcdb94e990be24f819ef.jpg', 'Chilly-Mazarin', 'Rue de l\'École', '91380', 31, 11, 4, '2018-01-25 23:38:34'),
(23, 'active', 'Voiture', ' Quaeque, ut ea vina, quae vetustatem ferunt, esse debet suavissima; verumque illud est, quod dicitur, multos modios salis simul edendos esse, ut amicitiae munus expletum sit.\n', 'Pellentesque gravida dui id turpis tincidunt mollis. Nulla facilisi. Etiam quis enim lorem. Duis lobortis diam et dolor accumsan, nec fermentum urna scelerisque. Nulla aliquet tortor sed risus facilisis bibendum. Nulla facilisi. Suspendisse semper rutrum sapien vel cursus. Sed id urna dolor. Cras id ex ac lectus ornare bibendum ac nec enim. Fusce fringilla ornare erat, vitae congue sem consequat vitae. Nullam finibus iaculis sodales. Aliquam interdum interdum tellus sit amet rhoncus. Phasellus sed ante consequat, ornare ex ac, porttitor libero. Suspendisse laoreet metus libero, sit amet vulputate turpis pellentesque vel. ', 54300, '980aea52acd392f0543d5b80705d213c.jpg', 'Bordeaux', '38-36 Cours Pasteur', '33000', 31, 6, 9, '2018-01-30 23:39:20'),
(24, 'active', 'Appartement Grand Luxe', ' Quaeque, ut ea vina, quae vetustatem ferunt, esse debet suavissima; verumque illud est, quod dicitur, multos modios salis simul edendos esse, ut amicitiae munus expletum sit.\n', 'Pellentesque gravida dui id turpis tincidunt mollis. Nulla facilisi. Etiam quis enim lorem. Duis lobortis diam et dolor accumsan, nec fermentum urna scelerisque. Nulla aliquet tortor sed risus facilisis bibendum. Nulla facilisi. Suspendisse semper rutrum sapien vel cursus. Sed id urna dolor. Cras id ex ac lectus ornare bibendum ac nec enim. Fusce fringilla ornare erat, vitae congue sem consequat vitae. Nullam finibus iaculis sodales. Aliquam interdum interdum tellus sit amet rhoncus. Phasellus sed ante consequat, ornare ex ac, porttitor libero. Suspendisse laoreet metus libero, sit amet vulputate turpis pellentesque vel. ', 1435660, '30f3c9a5a857a72f2d39be7a8f19ad9b.jpg', 'Nantes', 'Rue des Hauts Pavés', '44000', 31, 3, 7, '2018-02-01 23:40:05'),
(26, 'active', 'Télévision HD 4K', ' Quaeque, ut ea vina, quae vetustatem ferunt, esse debet suavissima; verumque illud est, quod dicitur, multos modios salis simul edendos esse, ut amicitiae munus expletum sit.\n', 'Pellentesque gravida dui id turpis tincidunt mollis. Nulla facilisi. Etiam quis enim lorem. Duis lobortis diam et dolor accumsan, nec fermentum urna scelerisque. Nulla aliquet tortor sed risus facilisis bibendum. Nulla facilisi. Suspendisse semper rutrum sapien vel cursus. Sed id urna dolor. Cras id ex ac lectus ornare bibendum ac nec enim. Fusce fringilla ornare erat, vitae congue sem consequat vitae. Nullam finibus iaculis sodales. Aliquam interdum interdum tellus sit amet rhoncus. Phasellus sed ante consequat, ornare ex ac, porttitor libero. Suspendisse laoreet metus libero, sit amet vulputate turpis pellentesque vel. ', 98, 'd23718e7daedad5d0c53d1a66e06fff3.jpg', 'Marseille', '2-12 Boulevard Jeanne d\'Arc', '13005', 31, 7, 13, '2018-02-05 00:10:55'),
(27, 'active', 'Téléphone ultra-moderne', ' Quaeque, ut ea vina, quae vetustatem ferunt, esse debet suavissima; verumque illud est, quod dicitur, multos modios salis simul edendos esse, ut amicitiae munus expletum sit.\n', 'Pellentesque gravida dui id turpis tincidunt mollis. Nulla facilisi. Etiam quis enim lorem. Duis lobortis diam et dolor accumsan, nec fermentum urna scelerisque. Nulla aliquet tortor sed risus facilisis bibendum. Nulla facilisi. Suspendisse semper rutrum sapien vel cursus. Sed id urna dolor. Cras id ex ac lectus ornare bibendum ac nec enim. Fusce fringilla ornare erat, vitae congue sem consequat vitae. Nullam finibus iaculis sodales. Aliquam interdum interdum tellus sit amet rhoncus. Phasellus sed ante consequat, ornare ex ac, porttitor libero. Suspendisse laoreet metus libero, sit amet vulputate turpis pellentesque vel. ', 45, 'd78b3793db44800aa5ebd3a210b570c1.jpg', 'Toulouse', '2-56 Rue Pierre d\'Aragon', '31200', 31, 7, 7, '2018-02-14 10:01:58'),
(28, 'active', 'Jupe \"Tube\" rouge', ' Quaeque, ut ea vina, quae vetustatem ferunt, esse debet suavissima; verumque illud est, quod dicitur, multos modios salis simul edendos esse, ut amicitiae munus expletum sit.\n', 'Pellentesque gravida dui id turpis tincidunt mollis. Nulla facilisi. Etiam quis enim lorem. Duis lobortis diam et dolor accumsan, nec fermentum urna scelerisque. Nulla aliquet tortor sed risus facilisis bibendum. Nulla facilisi. Suspendisse semper rutrum sapien vel cursus. Sed id urna dolor. Cras id ex ac lectus ornare bibendum ac nec enim. Fusce fringilla ornare erat, vitae congue sem consequat vitae. Nullam finibus iaculis sodales. Aliquam interdum interdum tellus sit amet rhoncus. Phasellus sed ante consequat, ornare ex ac, porttitor libero. Suspendisse laoreet metus libero, sit amet vulputate turpis pellentesque vel. ', 45, 'ac788b2c1d23c3e39b110045cd27b25a.jpg', 'Strasbourg', '6a Quai Turckheim', '67000', 31, 4, 6, '2018-02-17 21:21:52'),
(29, 'active', 'Chapeau de The Mask', 'Quaeque, ut ea vina, quae vetustatem ferunt, esse debet suavissima; verumque illud est, quod dicitur, multos modios salis simul edendos esse, ut amicitiae munus expletum sit.', 'Pellentesque gravida dui id turpis tincidunt mollis. Nulla facilisi. Etiam quis enim lorem. Duis lobortis diam et dolor accumsan, nec fermentum urna scelerisque. Nulla aliquet tortor sed risus facilisis bibendum. Nulla facilisi. Suspendisse semper rutrum sapien vel cursus. Sed id urna dolor. Cras id ex ac lectus ornare bibendum ac nec enim. Fusce fringilla ornare erat, vitae congue sem consequat vitae. Nullam finibus iaculis sodales. Aliquam interdum interdum tellus sit amet rhoncus. Phasellus sed ante consequat, ornare ex ac, porttitor libero. Suspendisse laoreet metus libero, sit amet vulputate turpis pellentesque vel. ', 567, '0b0630eeeedc5d2ba344303c69c23508.jpg', 'Toulouse', '49-37 Rue de la Sainte-Famille', '31200', 33, 7, 11, '2018-02-17 21:30:31'),
(30, 'active', 'Superbes gants maculés', 'Quaeque, ut ea vina, quae vetustatem ferunt, esse debet suavissima; verumque illud est, quod dicitur, multos modios salis simul edendos esse, ut amicitiae munus expletum sit.', 'Pellentesque gravida dui id turpis tincidunt mollis. Nulla facilisi. Etiam quis enim lorem. Duis lobortis diam et dolor accumsan, nec fermentum urna scelerisque. Nulla aliquet tortor sed risus facilisis bibendum. Nulla facilisi. Suspendisse semper rutrum sapien vel cursus. Sed id urna dolor. Cras id ex ac lectus ornare bibendum ac nec enim. Fusce fringilla ornare erat, vitae congue sem consequat vitae. Nullam finibus iaculis sodales. Aliquam interdum interdum tellus sit amet rhoncus. Phasellus sed ante consequat, ornare ex ac, porttitor libero. Suspendisse laoreet metus libero, sit amet vulputate turpis pellentesque vel. ', 778, 'a126c5bcc405349ac430618ac34ca931.jpg', 'Caen', '12 Rue d\'Hastings', '14000', 33, 10, 9, '2018-02-17 21:42:34'),
(31, 'active', 'Pantalon vintage', 'qsbmdf qmosn maozib efmoibegmiebm gfbemoi bgzmiejbfglzi', 'Pellentesque gravida dui id turpis tincidunt mollis. Nulla facilisi. Etiam quis enim lorem. Duis lobortis diam et dolor accumsan, nec fermentum urna scelerisque. Nulla aliquet tortor sed risus facilisis bibendum. Nulla facilisi. Suspendisse semper rutrum sapien vel cursus. Sed id urna dolor. Cras id ex ac lectus ornare bibendum ac nec enim. Fusce fringilla ornare erat, vitae congue sem consequat vitae. Nullam finibus iaculis sodales. Aliquam interdum interdum tellus sit amet rhoncus. Phasellus sed ante consequat, ornare ex ac, porttitor libero. Suspendisse laoreet metus libero, sit amet vulputate turpis pellentesque vel. ', 123, '1feac6958dbc00f7764a0dcdf4230980.jpg', 'Nimes', '1 rue fulton', '30000', 3, 8, 11, '2018-03-01 22:32:22'),
(32, 'active', 'Ordi tout neuf', 'se ille Philo, numquam Rupilio, numquam Mummio anteposuit, numquam inferioris ordinis', 'Adolescebat autem obstinatum propositum erga haec et similia multa scrutanda, stimulos admovente regina, quae abrupte mariti fortunas trudebat in exitium praeceps, cum eum potius lenitate feminea ad veritatis humanitatisque viam reducere utilia suadendo deberet, ut in Gordianorum actibus factitasse Maximini', 1234, '24148a6bae07644fa9056dce2d0005e9.jpg', 'Bordeaux', '66 Rue Abbé de l\'Épée', '33000', 36, 6, 10, '2018-03-11 17:11:28'),
(33, 'active', 'Lot de brosses à dents neuf', 'Utque proeliorum periti rectores primo catervas densas opponunt et fortes, deinde', 'Quae dum ita struuntur, indicatum est apud Tyrum indumentum regale textum occulte, incertum quo locante vel cuius usibus apparatum. ideoque rector provinciae tunc pater Apollinaris eiusdem nominis ut conscius ductus est aliique congregati sunt ex diversis civitatibus multi, qui atrocium criminum ponderibus urgebantur.', 76, '70671992bb4ed55c2953959e212690d8.jpg', 'Orléans', '54 Rue de la Cigogne', '45100', 38, 10, 12, '2018-03-11 17:14:40'),
(34, 'active', 'Meuble récent', 'lkqhsmldhf pqs dfbhq msdmhb lmqisdubf liqudfs o hqosglihg lqsdf', 'Utque proeliorum periti rectores primo catervas densas opponunt et fortes, deinde leves armaturas, post iaculatores ultimasque subsidiales acies, si fors adegerit, iuvaturas, ita praepositis urbanae familiae suspensae digerentibus sollicite, quos insignes faciunt virgae dexteris aptatae velut tessera data castrensi iuxta vehiculi frontem omne textrinum incedit: huic atratum coquinae iungitur ministerium, dein totum promiscue servitium cum otiosis plebeiis de vicinitate coniunctis: postrema multitudo spadonum a senibus in pueros', 577, '4f0d21f20715675f4d583456afe97dea.jpg', 'Bastia', 'Rue des Tilleuls', '20600', 16, 5, 5, '2018-03-11 17:25:15'),
(35, 'inactive', 'Machine à café de l\'espace', 'amicitia parem esse inferiori. Saepe enim excellentiae quaedam sunt', 'Utque proeliorum periti rectores primo catervas densas opponunt et fortes, deinde leves armaturas, post iaculatores ultimasque subsidiales acies, si fors adegerit, iuvaturas, ita praepositis urbanae familiae suspensae digerentibus sollicite, quos insignes faciunt virgae dexteris aptatae velut tessera data castrensi iuxta vehiculi frontem omne textrinum incedit: huic atratum coquinae iungitur', 230, 'c13f6e9ab2a755acb7c06ae9fe2da746.jpg', 'Lille', '48 Rue de Vieille Aventure', '59000', 37, 4, 9, '2018-03-11 22:30:26'),
(36, 'inactive', 'Cheminée pour l\'hiver', 'quaedam sunt, qualis erat Scipionis in nostro, ut ita dicam, grege.', 'Adolescebat autem obstinatum propositum erga haec et similia multa scrutanda, stimulos admovente regina, quae abrupte mariti fortunas trudebat in exitium praeceps, cum eum potius lenitate feminea ad veritatis humanitatisque viam reducere utilia suadendo deberet, ut in Gordianorum actibus factitasse Maximini truculenti illius imperatoris rettulimus coniugem.', 3456, '8e26fb13bf251969215e43ff6ddfcd90.jpg', 'Grenoble', '20 Rue Charrel', '38000', 37, 5, 13, '2018-03-11 22:32:59'),
(37, 'active', 'Sani en parfait état (non sale !)', 'cum otiosis plebeiis de vicinitate coniunctis: postrema multitudo spadonum a senibus', 'Isdem diebus Apollinaris Domitiani gener, paulo ante agens palatii Caesaris curam, ad Mesopotamiam missus a socero per militares numeros immodice scrutabatur, an quaedam altiora meditantis iam Galli secreta susceperint scripta, qui conpertis Antiochiae gestis per minorem Armeniam lapsus Constantinopolim petit exindeque per protectores retractus artissime tenebatur.', 980, '5a03eba24817ba2128f6addcea9139e3.jpg', 'Mulhouse', '10 Rue de la Largué', '68200', 9, 5, 6, '2018-03-11 22:55:03'),
(38, 'active', 'Tablette tactile en bois', 'Accenderat super his incitatum propositum ad nocendum aliqua mulier vilis.', 'Mox dicta finierat, multitudo omnis ad, quae imperator voluit, promptior laudato consilio consensit in pacem ea ratione maxime percita, quod norat expeditionibus crebris fortunam eius in malis tantum civilibus vigilasse, cum autem bella moverentur externa, accidisse plerumque luctuosa, icto post haec foedere gentium ritu perfectaque sollemnitate imperator Mediolanum ad hiberna discessit.', 560, '4de667b75b7d220df790b6690c1419ce.jpg', 'Dijon', '132 Rue Berbisey', '21000', 15, 6, 2, '2018-03-11 22:58:47'),
(39, 'active', 'Radiateur à chats', 'Equitis Romani autem esse filium criminis loco poni ab accusatoribus neque his iudicantibus oportuit', 'Ultima Syriarum est Palaestina per intervalla magna protenta, cultis abundans terris et nitidis et civitates habens quasdam egregias, nullam nulli cedentem sed sibi vicissim velut ad perpendiculum aemulas: Caesaream, quam ad honorem Octaviani principis exaedificavit Herodes, et Eleutheropolim et Neapolim itidemque Ascalonem Gazam aevo superiore exstructas.', 130, '0f324c8b2a5d75dead7913bed3e66e76.jpg', 'Lyon', '278 Rue André Philip', '69003', 15, 5, 1, '2018-03-11 23:08:47'),
(40, 'active', 'Dernière annonce', 'dsqlmfkj qmosihdf mqbmq bsmdifuqb lisbudfliqubs ldf', 'Equitis Romani autem esse filium criminis loco poni ab accusatoribus neque his iudicantibus oportuit neque defendentibus nobis. Nam quod de pietate dixistis, est quidem ista nostra existimatio, sed iudicium certe parentis; quid nos opinemur, audietis ex iuratis; quid parentes sentiant, lacrimae matris incredibilisque maeror, squalor patris et haec praesens maestitia, quam cernitis, luctusque declarat.', 456, '2ce729d944b3a3f0eb99d1e3b940a04a.jpg', 'Brest', '9 Rue Daumier', '29200', 37, 3, 3, '2018-03-11 23:12:20');

-- --------------------------------------------------------

--
-- Structure de la table `categorie`
--

DROP TABLE IF EXISTS `categorie`;
CREATE TABLE `categorie` (
  `id` int(10) UNSIGNED NOT NULL,
  `titre` varchar(100) NOT NULL,
  `mots_cles` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `categorie`
--

INSERT INTO `categorie` (`id`, `titre`, `mots_cles`) VALUES
(1, 'Emplois', 'Offres d\'emploi, Missions, CDD, CDI'),
(2, 'Immobilier', 'Ventes, Locations, Colocations, Bureaux, Logement'),
(3, 'Loisirs', 'Films, Musique, Livres, DVD, CD, Bandes dessinées, Jeux de société'),
(4, 'Matériel', 'Outillage, Fournitures de bureau, Matériel agricole'),
(5, 'Meubles', 'Lits, Commodes, Tables, Chaises, Postes de travail, Bureaux en bois'),
(6, 'Multimedia', 'Jeux vidéos, Informatique, Image, Son, Téléphones'),
(7, 'Services', 'Prestations de services, Événements, Ménage à domicile, Service à la personne'),
(8, 'Vacances', 'Camping, Hotels, Hôtes, Maisons d\'hotes, Piscine'),
(10, 'Vêtements', 'Robes, Blousons, Pantalons, Chemises, Foulards, Chaussettes'),
(11, 'Autres', 'Divers ');

-- --------------------------------------------------------

--
-- Structure de la table `commentaire`
--

DROP TABLE IF EXISTS `commentaire`;
CREATE TABLE `commentaire` (
  `id` int(10) UNSIGNED NOT NULL,
  `commentaire` text NOT NULL,
  `membre_id` int(10) UNSIGNED DEFAULT NULL,
  `annonce_id` int(10) UNSIGNED NOT NULL,
  `date_enregistrement` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `commentaire`
--

INSERT INTO `commentaire` (`id`, `commentaire`, `membre_id`, `annonce_id`, `date_enregistrement`) VALUES
(1, 'lmjdmq sdfqm sdbf^o^qosbdfmiqsbd mqksn dfpqb s^d fpqisbdf piqjsbdf piqbsdjf', 31, 27, '2018-02-15 12:17:40'),
(2, 'q d^s^qpdf^qns dnmqns pdibfqp pmqiosbd fmbqsmdfb qpisubdfqisubdf', 31, 27, '2018-02-15 12:17:57'),
(3, ' kqjbs dmfjn msldb^fmqbsmdbfjmqozbe^f qm bdgfqsdmoifb qpsidf', 31, 22, '2018-02-15 13:13:10'),
(4, 'ndm lqfn mlqskn ml kqmsldknf mqlksnm djbfmqk jsbdpf', 31, 22, '2018-02-15 13:13:23'),
(20, 'je réponds au commentaire', 31, 27, '2018-02-15 17:20:56'),
(23, 'trsè très joli\r\ncommentaire laissé par momo à lolo', 33, 28, '2018-02-17 21:50:51'),
(28, 'encore un commentraire laissé par Z 31', 31, 28, '2018-02-17 22:03:16'),
(29, 'je relaisse un commentaire', 33, 28, '2018-02-17 22:29:00'),
(30, 'azetvarta erth hsfh', 33, 28, '2018-02-17 22:32:16'),
(31, 'je suis Z 31 et je réponds au commentaire', 31, 28, '2018-02-17 22:36:46'),
(32, 'Trsè beau chapeau', 31, 29, '2018-02-17 22:59:02'),
(33, 'tes de réponse au commentaire', 33, 27, '2018-02-19 23:27:49'),
(34, 'c\'est vraiment nase comme appart !!!', 31, 24, '2018-02-24 15:46:52'),
(35, 'commentaire laissé par lolo 37', 37, 28, '2018-02-26 01:08:41'),
(36, 'commentaire de lolo 37', 37, 29, '2018-02-26 01:17:04'),
(37, 'commentaire pour l\'annonce de zz de la part de lolo', 37, 27, '2018-02-26 01:48:51'),
(38, 'Très vieille TV !!', 37, 26, '2018-03-04 20:02:47'),
(39, 'lolo 37 laisse un commentaire sur annonce zz 31', 37, 23, '2018-03-04 21:47:12'),
(40, 'MErci pour ce commentaire (laissé par zz)', 31, 23, '2018-03-04 21:50:05'),
(41, 'commentaire de zz sur l\'annonce de ZOZO', 31, 31, '2018-03-04 21:52:17'),
(43, 'question pour momo par lolo', 37, 30, '2018-03-04 22:00:20'),
(44, 'question de zz pour l\'annonce2 de momo', 31, 30, '2018-03-04 22:07:51'),
(205, 'mhqsld foalizbefolazhbeflqizbe flbez flqzjbe flqsjbdflqjsdbf', 31, 31, '2018-03-10 01:41:54'),
(206, '45453452345 mlqksjdf mqlskj', 31, 31, '2018-03-10 01:43:30'),
(207, 'commentaire de lolo pour l\'annonce de ZOZO', 37, 31, '2018-03-10 22:18:28'),
(208, 'Je suis momo et je réponds au commentaire de lolo', 33, 29, '2018-03-11 02:23:36'),
(209, 'tentative comment ajax', 31, 27, '2018-03-11 04:01:43'),
(210, 'tentaive encore jaax', 31, 28, '2018-03-11 05:05:13'),
(212, 'Soleo saepe ante oculos ponere, idque libenter crebris usurpare sermonibus, omnis nostrorum imperatorum, omnis exterarum gentium potentissimorumque populorum,', 4, 26, '2018-03-11 10:12:21'),
(213, 'omnis clarissimorum regum res gestas, cum tuis nec contentionum magnitudine nec', 33, 26, '2018-03-11 11:12:21'),
(214, 'vero disiunctissimas terras citius passibus cuiusquam potuisse peragrari, quam tuis', 37, 28, '2018-03-11 12:22:21'),
(215, 'magnitudine nec numero proeliorum nec varietate regionum nec celeritate', 9, 27, '2018-03-11 12:25:21'),
(216, 'nemo prudentior; nunc Laelius et sapiens (sic enim est habitus) et amicitiae gloria excellens de amicitia loquetur. Tu velim a me animum parumper', 15, 28, '2018-03-11 12:28:21'),
(217, 'Sed fruatur sane hoc solacio atque hanc insignem ignominiam, quoniam uni praeter se inusta sit, putet esse leviorem, dum', 36, 27, '2018-03-11 12:30:21'),
(218, 'Novitates autem si spem adferunt, ut tamquam in herbis non fallacibus fructus appareat, non sunt illae quidem repudiandae, vetustas tamen suo loco conservanda;', 44, 20, '2018-03-11 12:34:21'),
(219, 'animal, sed in iis etiam quae sunt inanima, consuetudo valet, cum locis ipsis delectemur', 36, 30, '2018-03-11 12:35:21'),
(220, 'jsdfqk qsmldkfj qjpsiçhdf pqn mqshdm fqbpsiduglfqibsdf', 3, 33, '2018-03-11 19:34:31'),
(221, 'rrrrrrrrrrrrr r  r rrrrrr rrrrrrrrr rrrrrr', 3, 29, '2018-03-11 21:31:51'),
(222, 'qmqmmqmqmqmqmqmqmqmqmqmqmmqmqmqmqmqmqmmq', 3, 29, '2018-03-11 21:34:42'),
(223, 'qg shrjyejy eyj etyjzertzyer t hzrjzrtjzrjydytj', 3, 29, '2018-03-11 21:38:54'),
(224, 'azerazer', 3, 29, '2018-03-11 21:52:04'),
(225, 'comemntaire commmentaire commentaire', 3, 29, '2018-03-11 22:13:24'),
(226, 'ghgltukbsryé \'(yz\' (ya \'hzrtz (je', 3, 29, '2018-03-11 22:16:33'),
(227, ' \'za\"j srjykjtu krukyiltlrke§èi e§èkr', 3, 29, '2018-03-11 22:16:50'),
(228, 'dfqs gageth zhaqh HHZYJZ YZH S', 3, 31, '2018-03-11 22:17:30'),
(229, 'BONJOUR MISTER\nTrès joli meuble !', 3, 34, '2018-03-11 22:19:04'),
(230, 'C\'est quoi ce truc ???', 3, 33, '2018-03-11 22:20:20'),
(231, 'Drole de choses !!', 3, 40, '2018-03-11 23:14:41'),
(232, 'qsdfq mqslkhdf qosd f^mqisugdfpqds pmifguqsdfdfdfdmfqsdmoqis', 3, 40, '2018-03-11 23:28:26'),
(233, 'qfqsdfqsdfqsdfqsdfqsdfqsdfqsdfqsdfqsdfqsdfqsdfqs', 3, 40, '2018-03-11 23:30:08');

-- --------------------------------------------------------

--
-- Structure de la table `mail`
--

DROP TABLE IF EXISTS `mail`;
CREATE TABLE `mail` (
  `id` int(10) UNSIGNED NOT NULL,
  `message` text NOT NULL,
  `membre_id1` int(10) UNSIGNED NOT NULL,
  `membre_id2` int(10) UNSIGNED NOT NULL,
  `annonce_id` int(10) UNSIGNED NOT NULL,
  `date_enregistrement` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `mail`
--

INSERT INTO `mail` (`id`, `message`, `membre_id1`, `membre_id2`, `annonce_id`, `date_enregistrement`) VALUES
(1, 'dsfqsdfq', 3, 37, 40, '2018-03-11 21:40:59'),
(2, 'je ne comprends pas votre annonce', 3, 37, 40, '2018-03-11 21:42:46');

-- --------------------------------------------------------

--
-- Structure de la table `membre`
--

DROP TABLE IF EXISTS `membre`;
CREATE TABLE `membre` (
  `id` int(10) UNSIGNED NOT NULL,
  `civilite` enum('M.','Mme') NOT NULL,
  `pseudo` varchar(45) NOT NULL,
  `mdp` varchar(255) NOT NULL,
  `nom` varchar(45) NOT NULL,
  `prenom` varchar(45) NOT NULL,
  `telephone` varchar(45) DEFAULT NULL,
  `email` varchar(45) NOT NULL,
  `role` enum('user','admin') NOT NULL,
  `date_enregistrement` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `membre`
--

INSERT INTO `membre` (`id`, `civilite`, `pseudo`, `mdp`, `nom`, `prenom`, `telephone`, `email`, `role`, `date_enregistrement`) VALUES
(3, 'M.', 'zozo', '$2y$10$hYt8xcR5f0cX.WkDaGRyYecr6CdGodyZxVCtAKV/GYXwrFmMglrh.', 'Zoletane', 'Zorba', '123423452', 'gfzegrz@gsegze.gt', 'user', '2018-02-09 11:28:59'),
(4, 'Mme', 'jojo', '$2y$10$PtKFCXM4s0.6OUHa/kC0xOIcJxI4UyjPn1hP69AahzSwW3j/mDL8m', 'Guiliguili', 'Josiane', '2232 554', 'rezaraze@qsdfqsdf.fr', 'user', '2018-02-09 11:37:30'),
(9, 'M.', 'zaza', '$2y$10$mQV7BFCNnNECHS7MNDl7lOMBqNtOr.kIn9XTgCs562zAeWk4X40x2', 'zaza', 'zaza', '61546441325', 'zaza@zaza.com', 'user', '2018-02-13 09:55:17'),
(15, 'M.', 'Minou', '$2y$10$lgCxBK5vSqx8acf2fvmAeeQ3jfNxmjrNBoBU3cNWJPWbsTDSLiIVC', 'Mimonpulalenver', 'Roger', '73278563', 'bzyz@gsdfgdsf.gdf', 'admin', '2018-02-13 16:26:54'),
(16, 'M.', 'mister', '$2y$10$squNP9bXAPKWhOlu/MiW..i0w1CxClVkCOiu8jtGFmXM8eBWd5/Uq', 'Karambar', 'Lolotte', '7567863', 'ZZZZZZZZzes@drfgszdrfghs.gt', 'admin', '2018-02-13 16:46:14'),
(31, 'Mme', 'zzz', '$2y$10$YBhADLrfQtpcKHQkp4BloOTpnaKSJC8Xwp3MyrQ1HIDezMHlW6AP.', 'Zimbous', 'Zaz', '35435', 'dfkqdhfjs@qdsfqsd.fr', 'admin', '2018-02-14 11:48:54'),
(33, 'Mme', 'momo', '$2y$10$dDykJHWrGkm8oM3VOFAeI.yqL8e38SbkAiU4InGVkrWAA41tZnvo.', 'Mobilut', 'Monique', '2345234652', 'qsmdofqsdf@sdgszgzer.ki', 'user', '2018-02-17 18:08:33'),
(36, 'Mme', 'yplus', '$2y$10$WvCPWw2JktpRumxAVoxVreinxCJC.44RMzoCY7gaLLcS.9Wn7/NsK', 'Plusqueterrible', 'Yvan', '12341234', 'dgsergs@zegzsg.ghy', 'user', '2018-02-20 22:11:21'),
(37, 'Mme', 'lolo', '$2y$10$eQt/Lv5wHAVHtyJ3gBmOS.4gIBYFv.2PA2uWbmGKXZT0n2xLRRhSW', 'Lobart', 'Laurence', '123412345', 'sdgf@dgqsdfg.gt', 'admin', '2018-02-20 22:48:08'),
(38, 'Mme', 'Chka', '$2y$10$BjtDKBmu3a50KWrFkw6tNukvTmsEHgjRHto8BIQRunYvFG1K5p.wy', 'Dede', 'Baba', '1342345325', 'dedebaba@chka.com', 'user', '2018-02-24 15:44:08'),
(44, 'Mme', 'hihi', '$2y$10$4yGog/ghCqFQyGY1I48Q3.qwkhoTh.wspWufSP3YL32Je.d/W9aTq', 'Hilary', 'Hilton', '12341234', 'qsdf@qsdfqsdf.fr', 'user', '2018-03-08 00:31:41'),
(50, 'M.', 'koko', '$2y$10$9Vy/LnopyI5ag4uBLl3SUOE86hddEtBoFlDIlMGegaJSqMxiP73.y', 'Konstance', 'Kotruin', '543732547635', 'kifoihjkdfg@kjdsqmfhg.fr', 'user', '2018-03-11 17:50:17');

-- --------------------------------------------------------

--
-- Structure de la table `message`
--

DROP TABLE IF EXISTS `message`;
CREATE TABLE `message` (
  `id` int(10) UNSIGNED NOT NULL,
  `civilite` enum('M.','Mme') NOT NULL,
  `prenom` varchar(45) DEFAULT NULL,
  `nom` varchar(45) NOT NULL,
  `email` varchar(45) NOT NULL,
  `sujet` varchar(100) NOT NULL,
  `message` text NOT NULL,
  `date_enregistrement` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `message`
--

INSERT INTO `message` (`id`, `civilite`, `prenom`, `nom`, `email`, `sujet`, `message`, `date_enregistrement`) VALUES
(1, 'M.', 'Oliko', 'Zouzou', 'qsldkfjhq@qdsfqqsd.hy', 'Demande de remb', 'mlqksdjf^qsh  pqosihd fpqihs  fpqishd pfq sbdfbqpsd fbqmbkmk qbsldfb qlbsdmfbqmsdkbfqlkjbsdf', '2018-03-08 19:31:38'),
(2, 'M.', 'Jean', 'Dubois', 'qsdfqsdf@sqsdfq.lo', 'Demande renseignements', 'qsmdkljm mqnmkh  qs mfonqps dbfp qsdpof qoms dfq smdhfmazbepif', '2018-03-10 20:41:26'),
(19, 'M.', 'Jean', 'Dubois', 'qsdfqsdf@sqsdfq.lo', 'Demande renseignements', 'qsmdkljm mqnmkh  qs mfonqps dbfp qsdpof qoms dfq smdhfmazbepif', '2018-03-10 21:28:58'),
(20, 'M.', 'Jean', 'Dubois', 'qsdfqsdf@sqsdfq.lo', 'Demande renseignements', 'qsmdkljm mqnmkh  qs mfonqps dbfp qsdpof qoms dfq smdhfmazbepif', '2018-03-10 21:32:41'),
(21, 'M.', 'Jean', 'Dubois', 'qsdfqsdf@sqsdfq.lo', 'Demande renseignements', 'qsmdkljm mqnmkh  qs mfonqps dbfp qsdpof qoms dfq smdhfmazbepif', '2018-03-10 21:32:49'),
(22, 'M.', 'Delphine', 'Auge', 'qsdfqsdf@qsdfqsdf.ko', 'Demande divers', 'proficisci pellexit vultu adsimulato saepius replicando quod flagrantibus votis eum videre frater cuperet patruelis, siquid per inprudentiam gestum', '2018-03-11 22:09:49'),
(23, 'Mme', 'Durita', 'Dupont', 'ageroglzbkz@lfdbebzae.frr', 'Demande de nouveauté', 'Accenderat super his incitatum propositum ad nocendum aliqua mulier vilis, quae ad palatium ut poposcerat intromissa insidias ei latenter obtendi prodiderat a militibus obscurissimis.', '2018-03-11 22:12:46');

-- --------------------------------------------------------

--
-- Structure de la table `notes`
--

DROP TABLE IF EXISTS `notes`;
CREATE TABLE `notes` (
  `id` int(10) UNSIGNED NOT NULL,
  `note` int(1) DEFAULT NULL,
  `avis` text,
  `membre_id1` int(10) UNSIGNED DEFAULT NULL,
  `membre_id2` int(10) UNSIGNED DEFAULT NULL,
  `date_enregistrement` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `notes`
--

INSERT INTO `notes` (`id`, `note`, `avis`, `membre_id1`, `membre_id2`, `date_enregistrement`) VALUES
(3, 4, 'qsvbqdfgqe a ergzerg', 31, 4, '2018-02-17 21:04:02'),
(4, 1, 'gsdgsfgherth', 33, 31, '2018-02-18 18:09:01'),
(11, 4, 'turtyurtyurtyu', 33, 4, '2018-02-18 19:33:52'),
(12, 5, 'jjjksqjdflqksdjlfqjk', 3, 4, '2018-02-19 19:35:34'),
(13, 5, 'ppppsdofodpp qmosdufpoqshdp fqs', 4, 31, '2018-02-20 19:38:09'),
(14, 5, 'ooooooooooooooooo', 9, 31, '2018-02-20 19:45:52'),
(15, 4, 'ppppppppppp', 8, 31, '2018-02-20 19:48:52'),
(16, 3, 'Pas mal', 31, 33, '2018-02-20 22:59:12'),
(17, 2, 'c\'est nul !', 38, 31, '2018-02-21 15:46:52'),
(18, 2, 'sqdmlj osdhfp iqbsifd qib sbfdiubq', 4, 15, '2018-02-21 22:59:12'),
(19, 4, 'opjspod hpqisupifugqs idgfb iuqbsd if', 3, 9, '2018-02-22 12:59:12'),
(20, 5, 'hsoopaihep pihpaoinpo afpiejgfeogrhp eiug', 9, 15, '2018-02-22 20:59:12'),
(22, 1, 'jhdpoihazpoij^ pohp qsihpziho epfoa if', 33, 37, '2018-02-23 01:59:12'),
(24, 5, 'iqdosihp ihpaziehfpaz ôfahipihaqpi', 8, 37, '2018-02-23 22:09:12'),
(25, 5, 'uihze paizhp oaizhpef apiubef', 16, 15, '2018-02-23 22:34:12'),
(26, 3, 'Un bon vendeur ! Merci encore.', 3, 16, '2018-03-11 22:19:04'),
(28, 5, 'avis de zz sur zozo', 31, 3, '2018-03-10 00:06:13'),
(29, 3, 'JE laisse un avis en tant que lolo', 37, 3, '2018-03-10 23:10:50'),
(30, 4, 'Très bon vendeur. Merci.', 3, 38, '2018-03-11 19:34:31'),
(32, 2, '', 3, 33, '2018-03-11 21:52:24'),
(33, 2, 'vendeur incertain', 3, 37, '2018-03-11 23:14:41');

-- --------------------------------------------------------

--
-- Structure de la table `region`
--

DROP TABLE IF EXISTS `region`;
CREATE TABLE `region` (
  `id` int(10) UNSIGNED NOT NULL,
  `nom` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `region`
--

INSERT INTO `region` (`id`, `nom`) VALUES
(1, 'Auvergne-Rhône-Alpes'),
(2, 'Bourgogne-Franche-Comte'),
(3, 'Bretagne'),
(4, 'Centre-Val de Loire'),
(5, 'Corse'),
(6, 'Grand Est'),
(7, 'Hauts-de-France'),
(8, 'Ile-de-France'),
(9, 'Normandie'),
(10, 'Nouvelle-Aquitaine'),
(11, 'Occitanie'),
(12, 'Pays de la Loire'),
(13, 'Provence-Alpes-Côte d\'Azur');

-- --------------------------------------------------------

--
-- Structure de la table `tri`
--

DROP TABLE IF EXISTS `tri`;
CREATE TABLE `tri` (
  `id` int(10) UNSIGNED NOT NULL,
  `tri` varchar(45) NOT NULL,
  `options` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `tri`
--

INSERT INTO `tri` (`id`, `tri`, `options`) VALUES
(1, 'a.id desc', 'les plus récentes'),
(2, 'a.id', 'les plus anciennes'),
(3, 'c.titre', 'catégories croissantes'),
(4, 'c.titre desc', 'catégories décroissantes'),
(5, 'a.prix', 'prix croissants'),
(6, 'a.prix desc', 'prix décroissants');

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `annonce`
--
ALTER TABLE `annonce`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_annonce_membre_idx` (`membre_id`),
  ADD KEY `fk_annonce_region_idx` (`region_id`),
  ADD KEY `fk_annonce_categorie_idx` (`categorie_id`);

--
-- Index pour la table `categorie`
--
ALTER TABLE `categorie`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `commentaire`
--
ALTER TABLE `commentaire`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_commentaire_membre_idx` (`membre_id`),
  ADD KEY `fk_commentaire_annonce_idx` (`annonce_id`);

--
-- Index pour la table `mail`
--
ALTER TABLE `mail`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_mail_membre_idx` (`membre_id1`),
  ADD KEY `fk_mail_annonce_idx` (`annonce_id`),
  ADD KEY `fk_mail_membreVendeur_idx` (`membre_id2`);

--
-- Index pour la table `membre`
--
ALTER TABLE `membre`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `pseudo_UNIQUE` (`pseudo`);

--
-- Index pour la table `message`
--
ALTER TABLE `message`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `notes`
--
ALTER TABLE `notes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_note_membre1_idx` (`membre_id1`),
  ADD KEY `fk_note_membre2_idx` (`membre_id2`);

--
-- Index pour la table `region`
--
ALTER TABLE `region`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `tri`
--
ALTER TABLE `tri`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `annonce`
--
ALTER TABLE `annonce`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;
--
-- AUTO_INCREMENT pour la table `categorie`
--
ALTER TABLE `categorie`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT pour la table `commentaire`
--
ALTER TABLE `commentaire`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=234;
--
-- AUTO_INCREMENT pour la table `mail`
--
ALTER TABLE `mail`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT pour la table `membre`
--
ALTER TABLE `membre`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=51;
--
-- AUTO_INCREMENT pour la table `message`
--
ALTER TABLE `message`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;
--
-- AUTO_INCREMENT pour la table `notes`
--
ALTER TABLE `notes`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;
--
-- AUTO_INCREMENT pour la table `region`
--
ALTER TABLE `region`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
--
-- AUTO_INCREMENT pour la table `tri`
--
ALTER TABLE `tri`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `annonce`
--
ALTER TABLE `annonce`
  ADD CONSTRAINT `fk_annonce_categorie` FOREIGN KEY (`categorie_id`) REFERENCES `categorie` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_annonce_membre` FOREIGN KEY (`membre_id`) REFERENCES `membre` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_annonce_region` FOREIGN KEY (`region_id`) REFERENCES `region` (`id`);

--
-- Contraintes pour la table `commentaire`
--
ALTER TABLE `commentaire`
  ADD CONSTRAINT `fk_commentaire_annonce` FOREIGN KEY (`annonce_id`) REFERENCES `annonce` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_commentaire_membre` FOREIGN KEY (`membre_id`) REFERENCES `membre` (`id`) ON DELETE SET NULL ON UPDATE SET NULL;

--
-- Contraintes pour la table `mail`
--
ALTER TABLE `mail`
  ADD CONSTRAINT `fk_mail_annonce` FOREIGN KEY (`annonce_id`) REFERENCES `annonce` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_mail_membreClient` FOREIGN KEY (`membre_id1`) REFERENCES `membre` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_mail_membreVendeur` FOREIGN KEY (`membre_id2`) REFERENCES `membre` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Contraintes pour la table `notes`
--
ALTER TABLE `notes`
  ADD CONSTRAINT `fk_notes_membre2` FOREIGN KEY (`membre_id2`) REFERENCES `membre` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
SET FOREIGN_KEY_CHECKS=1;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
